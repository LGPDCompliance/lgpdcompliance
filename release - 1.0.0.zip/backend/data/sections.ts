const sections = {
  create: [
    {title: 'Governança'},
    {title: 'Conformidade legal e respeito aos princípios'},
    {title: 'Transparência e direitos do titular'},
  ],
};

export default sections;
